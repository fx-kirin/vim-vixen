export default {
  // Settings
  SETTING_SET_SETTINGS: 'setting.set.settings',
  SETTING_SET_PROPERTY: 'setting.set.property',

  // Find
  FIND_SET_KEYWORD: 'find.set.keyword',
};
