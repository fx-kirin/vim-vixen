import CommonComponent from './common';

export default CommonComponent;
