export default {
  // Settings
  SETTING_SET_SETTINGS: 'setting.set.settings',
};
